// This file implements the check win functions for a Connect4 program
bool Check_Vertical(char move[], int loc, char XO, int winl[])
{
	int counter = 0; // used to count how many in a row
					 //If Player 1 just went, check if X won vertically
	if (XO == 'X')
	{
		counter++;
		if (move[loc + 21] == 'X')
		{
			counter++;
			if (move[loc + 14] == 'X')
			{
				counter++;
				if (move[loc + 7] == 'X') {
					counter++;
					if (winl[0] != -1) {
						winl[0] = loc;
						winl[1] = loc + 7;
						winl[2] = loc + 14;
						winl[3] = loc + 21;
					}
				}
			}
		}
	}

	if (counter == 4)
		return true;

	//If Player 2 just went, check if O won vertically
	if (XO == 'O')
	{
		counter++;
		if (move[loc + 21] == 'O')
		{
			counter++;
			if (move[loc + 14] == 'O')
			{
				counter++;
				if (move[loc + 7] == 'O') {
					counter++;
					if (winl[0] != -1) {
						winl[0] = loc;
						winl[1] = loc + 7;
						winl[2] = loc + 14;
						winl[3] = loc + 21;
					}
				}
			}
		}
	}
	if (counter == 4)
		return true;
	return false;
}

bool Check_Horizontal(char move[], int loc, char XO, int winl[])
{
	int counter = 0; // used to count how many in a row
					 // If X just went, check if X won horizontally
	if (XO == 'X')
	{
		if (move[loc + 1] == 'X' && (loc) % 7 != 6)
		{
			winl[1] = loc + 1;
			counter++;
			if (move[loc + 2] == 'X' && (loc + 1) % 7 != 6)
			{
				winl[2] = loc + 2;
				counter++;
				if (move[loc + 3] == 'X' && (loc + 2) % 7 != 6) {
					counter++;
					winl[3] = loc + 3;
				}
				else if (move[loc - 1] == 'X' && loc % 7 != 0) {
					counter++;
					winl[3] = loc - 1;
				}
			}
			else if (move[loc - 1] == 'X' && loc % 7 != 0)
			{
				winl[2] = loc - 1;
				counter++;
				if (move[loc - 2] == 'X' && (loc - 1) % 7 != 0) {
					counter++;
					winl[3] = loc - 2;
				}
			}
		}
		else if (move[loc - 1] == 'X' && loc % 7 != 0)
		{
			winl[1] = loc - 1;
			counter++;
			if (move[loc - 2] == 'X' && (loc - 1) % 7 != 0)
			{
				winl[2] = loc - 2;
				counter++;
				if (move[loc - 3] == 'X' && (loc - 2) % 7 != 0) {
					counter++;
					winl[3] = loc - 3;
				}
				else if (move[loc + 1] == 'X' && (loc) % 7 != 6) {
					counter++;
					winl[3] = loc + 1;
				}
			}
			else if (move[loc + 1] == 'X' && (loc) % 7 != 6)
			{
				winl[2] = loc + 1;
				counter++;
				if (move[loc + 2] == 'X' && (loc + 1) % 7 != 6) {
					counter++;
					winl[3] = loc + 2;
				}
			}
		}
	}
	if (counter == 3) {
		winl[0] = loc;
		return true;
	}
	else if (winl[0] == -1)
		for (int rs0 = 0; rs0 < 3; rs0++)
			winl[rs0 + 1] = -1;
	else if (winl[0] == -2)
		for (int rs1 = 0; rs1 < 3; rs1++)
			winl[rs1 + 1] = -2;

	// If O just went, check if O won horizontally
	if (XO == 'O')
	{
		if (move[loc + 1] == 'O' && (loc) % 7 != 6)
		{
			winl[1] = loc + 1;
			counter++;
			if (move[loc + 2] == 'O' && (loc + 1) % 7 != 6)
			{
				winl[2] = loc + 2;
				counter++;
				if (move[loc + 3] == 'O' && (loc + 2) % 7 != 6) {
					counter++;
					winl[3] = loc + 3;
				}
				else if (move[loc - 1] == 'O' && loc % 7 != 0) {
					counter++;
					winl[3] = loc - 1;
				}
			}
			else if (move[loc - 1] == 'O' && loc % 7 != 0)
			{
				winl[2] = loc - 1;
				counter++;
				if (move[loc - 2] == 'O' && (loc - 1) % 7 != 0) {
					counter++;
					winl[3] = loc - 2;
				}
			}
		}
		else if (move[loc - 1] == 'O' && loc % 7 != 0)
		{
			winl[1] = loc - 1;
			counter++;
			if (move[loc - 2] == 'O' && (loc - 1) % 7 != 0)
			{
				winl[2] = loc - 2;
				counter++;
				if (move[loc - 3] == 'O' && (loc - 2) % 7 != 0) {
					counter++;
					winl[3] = loc - 3;
				}
				else if (move[loc + 1] == 'O' && (loc) % 7 != 6) {
					counter++;
					winl[3] = loc + 1;
				}
			}
			else if (move[loc + 1] == 'O' && (loc) % 7 != 6)
			{
				winl[2] = loc + 1;
				counter++;
				if (move[loc + 2] == 'O' && (loc + 1) % 7 != 6) {
					counter++;
					winl[3] = loc + 2;
				}
			}
		}
	}
	if (counter == 3) {
		winl[0] = loc;
		return true;
	}
	else if (winl[0] == -1)
		for (int rs2 = 0; rs2 < 3; rs2++)
			winl[rs2 + 1] = -1;
	else if (winl[0] == -2)
		for (int rs3 = 0; rs3 < 3; rs3++)
			winl[rs3 + 1] = -2;

	return false;
}

bool Check_Diagonal(char move[], int loc, char XO, int winl[])
// Returns true if the most recent player just won diagonally
{
	int counter = 0; // used to count how many in a row
	int curr; // distance from loc to a wall of the board, to check for hitting a "wall" of the board
	curr = loc % 7;

	// If Player 1 just went, check diagonally on X one way
	if (XO == 'X')
	{
		if (move[loc - 8] == 'X' && curr  > 0)
		{
			counter++;
			winl[1] = loc - 8;
			if (move[loc - 16] == 'X' && curr > 1)
			{
				counter++;
				winl[2] = loc - 16;
				if (move[loc - 24] == 'X' && curr > 2) {
					counter++;
					winl[3] = loc - 24;
				}
				else if (move[loc + 8] == 'X' && curr < 6) {
					counter++;
					winl[3] = loc + 8;
				}
			}
			else if (move[loc + 8] == 'X' && curr < 6)
			{
				counter++;
				winl[2] = loc + 8;
				if (move[loc + 16] == 'X' && curr < 5) {
					counter++;
					winl[3] = loc + 16;
				}
			}
		}
		else if (move[loc + 8] == 'X' && curr < 6)
		{
			counter++;
			winl[1] = loc + 8;
			if (move[loc + 16] == 'X' && curr < 5)
			{
				counter++;
				winl[2] = loc + 16;
				if (move[loc + 24] == 'X' && curr < 4) {
					counter++;
					winl[3] = loc + 24;
				}
			}
		}
	}

	if (counter == 3) {
		winl[0] = loc;
		return true;
	}
	else if (winl[0] == -1)
		for (int rs0 = 0; rs0 < 3; rs0++)
			winl[rs0 + 1] = -1;
	else if (winl[0] == -2)
		for (int rs1 = 0; rs1 < 3; rs1++)
			winl[rs1 + 1] = -2;
	counter = 0;

	// If Player 1 just went, check diagonally on X the other way way
	if (XO == 'X')
	{
		if (move[loc - 6] == 'X' && curr < 6)
		{
			winl[1] = loc - 6;
			counter++;
			if (move[loc - 12] == 'X' && curr < 5)
			{
				winl[2] = loc - 12;
				counter++;
				if (move[loc - 18] == 'X' && curr < 4) {
					winl[3] = loc - 18;
					counter++;
				}
				else if (move[loc + 6] == 'X' && curr > 0) {
					winl[3] = loc + 6;
					counter++;
				}
			}
			else if (move[loc + 6] == 'X' && curr > 0)
			{
				winl[2] = loc + 6;
				counter++;
				if (move[loc + 12] == 'X' && curr > 1) {
					winl[3] = loc + 12;
					counter++;
				}
			}
		}
		else if (move[loc + 6] == 'X' && curr > 0)
		{
			winl[1] = loc + 6;
			counter++;
			if (move[loc + 12] == 'X' && curr > 1)
			{
				winl[2] = loc + 12;
				counter++;
				if (move[loc + 18] == 'X' && curr > 2) {
					winl[3] = loc + 18;
					counter++;
				}
			}
		}
	}
	if (counter == 3) {
		winl[0] = loc;
		return true;
	}
	else if (winl[0] == -1)
		for (int rs2 = 0; rs2 < 3; rs2++)
			winl[rs2 + 1] = -1;
	else if (winl[0] == -2)
		for (int rs3 = 0; rs3 < 3; rs3++)
			winl[rs3 + 1] = -2;

	// If Player 2 just went, check diagonally on X one way
	if (XO == 'O')
	{
		if (move[loc - 8] == 'O' && curr  > 0)
		{
			counter++;
			winl[1] = loc - 8;
			if (move[loc - 16] == 'O' && curr > 1)
			{
				counter++;
				winl[2] = loc - 16;
				if (move[loc - 24] == 'O' && curr > 2) {
					counter++;
					winl[3] = loc - 24;
				}
				else if (move[loc + 8] == 'O' && curr < 6) {
					counter++;
					winl[3] = loc + 8;
				}
			}
			else if (move[loc + 8] == 'O' && curr < 6)
			{
				counter++;
				winl[2] = loc + 8;
				if (move[loc + 16] == 'O' && curr < 5) {
					counter++;
					winl[3] = loc + 16;
				}
			}
		}
		else if (move[loc + 8] == 'O' && curr < 6)
		{
			counter++;
			winl[1] = loc + 8;
			if (move[loc + 16] == 'O' && curr < 5)
			{
				counter++;
				winl[2] = loc + 16;
				if (move[loc + 24] == 'O' && curr < 4) {
					counter++;
					winl[3] = loc + 24;
				}
			}
		}
	}

	if (counter == 3) {
		winl[0] = loc;
		return true;
	}
	else if (winl[0] == -1)
		for (int rs4 = 0; rs4 < 3; rs4++)
			winl[rs4 + 1] = -1;
	else if (winl[0] == -2)
		for (int rs5 = 0; rs5 < 3; rs5++)
			winl[rs5 + 1] = -2;
	counter = 0;

	// If Player 2 just went, check diagonally on X the other way way
	if (XO == 'O')
	{
		if (move[loc - 6] == 'O' && curr < 6)
		{
			winl[1] = loc - 6;
			counter++;
			if (move[loc - 12] == 'O' && curr < 5)
			{
				winl[2] = loc - 12;
				counter++;
				if (move[loc - 18] == 'O' && curr < 4) {
					winl[3] = loc - 18;
					counter++;
				}
				else if (move[loc + 6] == 'O' && curr > 0) {
					winl[3] = loc + 6;
					counter++;
				}
			}
			else if (move[loc + 6] == 'O' && curr > 0)
			{
				winl[2] = loc + 6;
				counter++;
				if (move[loc + 12] == 'O' && curr > 1) {
					winl[3] = loc + 12;
					counter++;
				}
			}
		}
		else if (move[loc + 6] == 'O' && curr > 0)
		{
			winl[1] = loc + 6;
			counter++;
			if (move[loc + 12] == 'O' && curr > 1)
			{
				winl[2] = loc + 12;
				counter++;
				if (move[loc + 18] == 'O' && curr > 2) {
					winl[3] = loc + 18;
					counter++;
				}
			}
		}
	}
	if (counter == 3) {
		winl[0] = loc;
		return true;
	}
	else if (winl[0] == -1)
		for (int rs6 = 0; rs6 < 3; rs6++)
			winl[rs6 + 1] = -1;
	else if (winl[0] == -2)
		for (int rs7 = 0; rs7 < 3; rs7++)
			winl[rs7 + 1] = -2;

	return false;
}

bool Check_Win(char move[], int loc, char XO, int winl[])
/* When passed the last move position, this function will calculate whether four consecutive 'O' or 'X' in a row occur.
It checks first vertically, then horizontally, then diagonally in each direction.
If a win occurs, the function passes back a boolean value which ends the while loop. */
{
	if (Check_Vertical(move, loc, XO, winl))
		return true;
	else if (Check_Horizontal(move, loc, XO, winl))
		return true;
	else if (Check_Diagonal(move, loc, XO, winl))
		return true;
	return false;
}