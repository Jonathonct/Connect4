#ifndef   __CheckWin__h
#define   __CheckWin__h
#include   "CheckWin.h"
#endif
#include <stdlib.h>

// This file implements a simple and slightly more complex algorithm for playing Connect 4
struct CLIST {
	bool valid = true; // if a column is valid for the AI to choose this turn
	bool isfull = false; // when the column is full and unusable
	bool last = false; // when column shouldn't be used 1 turn only
}; // data structure used by AI for decision making

int Get_Bottom(char move[], int row)
// This function returns the bottom index which is open of a given row, 1-7
// Note this function should never be called for a row which is full
{
	int k;
	for (k = row + 41; k >= 0;)
	{
		if (move[k] == ' ')
			return k;
		else
			k = k - 7;
	}
	return 49; // Index never used, kept in case of error to avoid memory discrepancies
}

void AI_Fail(char move[], CLIST clist[], int hwin[])
// Hard AI mode function that prevents user from winning off of AI's move by marking all inappropriate moves
{
	bool fail = false; // Assume AI's move did not fail. Until it does
	int k[7]; // Used to perform logic
	int k0 = 0;
	int k1 = 0;

	// Simulate all possible AI moves in each column
	for (int j = 1; j < 8; j++)
	{
		if (!clist[j - 1].isfull) {
			k0 = Get_Bottom(move, j);
			move[k0] = 'O';
			k[j - 1] = k0; // Save location of AI's simulated move
		}
	}

	// Simulate Player's move
	for (int l = 1; l < 8; l++)
		if (!clist[l - 1].isfull) {
			k1 = Get_Bottom(move, l);
			if (Check_Win(move, k1, 'X', hwin)) {
				fail = true; // Identified a win off of the Player's move
				clist[l - 1].last = true; // This move shouldn't be used this turn
				move[k1] = ' ';
			}
		}
		else if (clist[l - 1].isfull)
			clist[l - 1].last = true;

	// Undo simulation of AI's move
	for (int x = 0; x < 7; x++)
		if (k[x] >= 0)
			if (!clist[x].isfull)
				move[k[x]] = ' ';
}

void Get_Openings(int openings[], char move[], CLIST clist[])
// Hard AI function which reveals the location for the bottom of each row
{
	for (int i = 1; i < 8; i++)
		if (!clist[i - 1].isfull)
			openings[i - 1] = Get_Bottom(move, i);
		else
			openings[i - 1] = -1;
}

int AI_Move(char move[], int& turn, int& loc, CLIST clist[], bool hard, int hwin[])
{
	int column = -1; // Used to determine if a priority move has been found by the ai
	int k, gg; // Used to test potential moves by the ai

			   // If the AI can win, win
	for (int j = 1; j < 8; j++)
		if (!clist[j - 1].isfull) {
			k = Get_Bottom(move, j);
			if (k != 49)
				move[k] = 'O';
			if (Check_Win(move, k, 'O', hwin))
				column = j;
			move[k] = ' ';
		}

	// If you can win, stop you from winning
	if (column == -1)
		for (int l = 1; l < 8; l++)
			if (!clist[l - 1].isfull) {
				k = Get_Bottom(move, l);
				if (k != 49)
					move[k] = 'X';
				if (Check_Win(move, k, 'X', hwin))
					column = l;
				move[k] = ' ';
			}

	int openings[7];
	Get_Openings(openings, move, clist);

	// Hard AI decision making
	if (hard && column == -1)
		while (true)
		{
			// Start turn by marking all moves which AI can't make
			for (int x = 0; x < 7; x++)
				clist[x].last = false; // reset one-turn only validity from last turn for all 7 columns
			AI_Fail(move, clist, hwin);

			// Take middle block if user hasn't
			if (move[45] == ' ') {
				column = 4;
				break;
			}

			// If placing in a column causes a win with the two blocks above and doesn't give user win, go there
			for (int ggez = 1; ggez < 8; ggez++)
				if (!clist[ggez - 1].isfull)
					if (!clist[ggez - 1].last)
						if (openings[ggez - 1] > 13) {
							move[openings[ggez - 1]] = 'O';
							if (Check_Win(move, (openings[ggez - 1] - 7), 'O', hwin)) {
								column = ggez;
								move[openings[ggez - 1]] = ' ';
								break;
							}
							move[openings[ggez - 1]] = ' ';
						}
			if (column != -1)
				break;

			// Go for horizontal win with multidirectional 3-in-a-row w/ open space
			int ref = openings[3]; // Index of column 4 opening. 
			if (ref + 1 != -1 || ref - 1 != -1 || ref + 2 != -1 || ref - 2 != -1)
				for (int y = 0; y < 7; y++) {
					if (move[45 - 7 * y] == 'O')
						if (move[44 - 7 * y] == 'O') // AI has two horizontal in a row, columns 4 and 3
						{
							if (move[42 - y * 7] != 'X' && move[46 - y * 7] != 'X') // Test if rows 1-5  or 2-6 are open
								if (openings[1] == 43 - 7 * y) // If row 2 grants a mutual 3-in a row with openings on both, do it
									if (!clist[y].last)
									{
										column = 2;
										break;
									}
							if (move[43 - y * 7] != 'X' && move[47 - y * 7] != 'X') // Test if 2-6 are open
								if (openings[4] == 46 - 7 * y) // If row 6 grants a mutual 3-in a row with openings on both, do it
									if (!clist[y].last)
									{
										column = 5;
										break;
									}
						}
					if (move[45 - 7 * y] == 'O')
						if (move[46 - 7 * y] == 'O') // AI has two horizontal in a row, columns 4 and 5
						{
							if (move[44 - y * 7] != 'X' && move[48 - y * 7] != 'X') // Test if rows 3-7 
								if (openings[5] == 47 - 7 * y) // If row 6 grants a mutual 3-in a row with openings on both, do it
									if (!clist[y].last)
									{
										column = 6;
										break;
									}
							if (move[43 - y * 7] != 'X' && move[47 - y * 7] != 'X') // Test if 2-6 are open
								if (openings[2] == 44 - 7 * y) // If row 6 grants a mutual 3-in a row with openings on both, do it
									if (!clist[y].last)
									{
										column = 3;
										break;
									}
						}
					if ((std::rand() % 10 + 1) % 2 == 0) {
						if (move[45 - 7 * y] == 'O')
							if (move[44 - 7 * y] == ' ' && move[46 - 7 * y] == ' ') // Row 4 taken, 3 and 5 open
								if ((move[43 - 7 * y] == ' ' || move[43 - 7 * y] == 'O') && (move[42 - 7 * y] == ' ' || move[42 - 7 * y] == 'O'))
									if (openings[2] == 44 - 7 * y)
										if (!clist[y].last) {
											column = 3; // Make 4 and 3 combo, setting up for 2-3-4
											break;
										}
						if (move[45 - 7 * y] == 'O')
							if (move[44 - 7 * y] == ' ' && move[46 - 7 * y] == ' ') // Row 4 taken, 3 and 5 open
								if ((move[47 - 7 * y] == ' ' || move[47 - 7 * y] == 'O') && (move[48 - 7 * y] == ' ' || move[48 - 7 * y] == 'O'))
									if (openings[4] == 46 - 7 * y)
										if (!clist[y].last) {
											column = 5; // Make 4 and 5 combo, setting up for 4-5-6
											break;
										}
					}
					else {
						// Same thing as previous, just in different order to promote randomness
						if (move[45 - 7 * y] == 'O')
							if (move[44 - 7 * y] == ' ' && move[46 - 7 * y] == ' ')
								if ((move[47 - 7 * y] == ' ' || move[47 - 7 * y] == 'O') && (move[48 - 7 * y] == ' ' || move[48 - 7 * y] == 'O'))
									if (openings[4] == 46 - 7 * y)
										if (!clist[y].last) {
											column = 5;
											break;
										}
						if (move[45 - 7 * y] == 'O')
							if (move[44 - 7 * y] == ' ' && move[46 - 7 * y] == ' ')
								if ((move[43 - 7 * y] == ' ' || move[43 - 7 * y] == 'O') && (move[42 - 7 * y] == ' ' || move[42 - 7 * y] == 'O'))
									if (openings[2] == 44 - 7 * y)
										if (!clist[y].last) {
											column = 3;
											break;
										}
					}
				}
			if (column != -1)
				break;

			// Prevent player from doing the above strategy
			if (ref + 1 != -1 || ref - 1 != -1 || ref + 2 != -1 || ref - 2 != -1)
				for (int y1 = 0; y1 < 7; y1++) {
					if (move[45 - 7 * y1] == 'X')
						if (move[44 - 7 * y1] == 'X') // Player has two horizontal in a row, columns 4 and 3
						{
							if (move[42 - y1 * 7] != 'O' && move[46 - y1 * 7] != 'O') // Test if rows 1-5  or 2-6 are open
								if (openings[1] == 43 - 7 * y1) // If row 2 grants a mutual 3-in a row with openings on both, prevent it
									if (!clist[y1].last)
									{
										column = 2;
										break;
									}
							if (move[43 - y1 * 7] != 'O' && move[47 - y1 * 7] != 'O') // Test if 2-6 are open
								if (openings[4] == 46 - 7 * y1) // If row 6 grants a mutual 3-in a row with openings on both, prevent it
									if (!clist[y1].last)
									{
										column = 5;
										break;
									}
						}
					if (move[45 - 7 * y1] == 'X')
						if (move[46 - 7 * y1] == 'X') // Player has two horizontal in a row, columns 4 and 5
						{
							if (move[44 - y1 * 7] != 'O' && move[48 - y1 * 7] != 'O') // Test if rows 3-7 
								if (openings[5] == 47 - 7 * y1) // If row 6 grants a mutual 3-in a row with openings on both, prevent it
									if (!clist[y1].last)
									{
										column = 6;
										break;
									}
							if (move[43 - y1 * 7] != 'O' && move[47 - y1 * 7] != 'O') // Test if 2-6 are open
								if (openings[2] == 44 - 7 * y1) // If row 6 grants a mutual 3-in a row with openings on both, prevent it
									if (!clist[y1].last)
									{
										column = 3;
										break;
									}
						}
					if ((std::rand() % 10 + 1) % 2 == 0) {
						if (move[45 - 7 * y1] == 'X')
							if (move[44 - 7 * y1] == ' ' && move[46 - 7 * y1] == ' ') // Row 4 taken, 3 and 5 open
								if ((move[43 - 7 * y1] == ' ' || move[43 - 7 * y1] == 'X') && (move[42 - 7 * y1] == ' ' || move[42 - 7 * y1] == 'X'))
									if (openings[2] == 44 - 7 * y1)
										if (!clist[y1].last) {
											column = 3; // Prevent 4-3 combo, setting up for 2-3-4
											break;
										}
						if (move[45 - 7 * y1] == 'X')
							if (move[44 - 7 * y1] == ' ' && move[46 - 7 * y1] == ' ') // Row 4 taken, 3 and 5 open
								if ((move[47 - 7 * y1] == ' ' || move[47 - 7 * y1] == 'X') && (move[48 - 7 * y1] == ' ' || move[48 - 7 * y1] == 'X'))
									if (openings[4] == 46 - 7 * y1)
										if (!clist[y1].last) {
											column = 5; // Prevent 4 and 5 combo, setting up for 4-5-6
											break;
										}
					}
					else {
						// Same thing as previous, just in different order to promote randomness
						if (move[45 - 7 * y1] == 'X')
							if (move[44 - 7 * y1] == ' ' && move[46 - 7 * y1] == ' ')
								if ((move[47 - 7 * y1] == ' ' || move[47 - 7 * y1] == 'X') && (move[48 - 7 * y1] == ' ' || move[48 - 7 * y1] == 'X'))
									if (openings[4] == 46 - 7 * y1)
										if (!clist[y1].last) {
											column = 5;
											break;
										}
						if (move[45 - 7 * y1] == 'X')
							if (move[44 - 7 * y1] == ' ' && move[46 - 7 * y1] == ' ')
								if ((move[43 - 7 * y1] == ' ' || move[43 - 7 * y1] == 'X') && (move[42 - 7 * y1] == ' ' || move[42 - 7 * y1] == 'X'))
									if (openings[2] == 44 - 7 * y1)
										if (!clist[y1].last) {
											column = 3;
											break;
										}
					}
				}
			if (column != -1)
				break;

			// Advance diagonal when already 2 diagonal in a row
			for (int d = 1; d < 8; d++) {
				int curr = openings[d - 1];
				// Simulate diagonal two in a rows for column 1
				if (d == 1) {
					// Case 1
					if (curr > 14) {
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 12] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}
					// Case 2
					if (curr < 28) {
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 16] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 1 loop

				  // Simulate diagonal two in a rows for column 2
				if (d == 2) {
					// Case 1
					if (curr > 8 && curr < 43) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 15) {
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 12] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					// Case 2
					if (curr < 29) {
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 16] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
					if (curr < 36 && curr > 1) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 2 loop

				  // Simulate diagonal two in a rows for column 3
				if (d == 3) {
					// Case 1
					if (curr > 2) {
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 3 && curr < 37) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr < 30) {
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 12] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					// Case 2
					if (curr < 30) {
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 16] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 37 && curr > 3) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 44 && curr > 9) {
						if (move[curr + 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr - 8] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 8] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 3 loop

				  // Simulate diagonal two in a rows for column 4
				if (d == 4) {
					// Case 1
					if (curr < 31) {
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 18] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 12] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
					}

					if (curr > 10 && curr < 46) {
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 10 && curr < 38) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 17) {
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 12] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					// Case 2
					if (curr < 31) {
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 16] == 'O' && move[curr + 24] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 38 && curr > 3) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 45 && curr > 10) {
						if (move[curr + 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr - 8] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 8] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr > 17) {
						if (move[curr - 24] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 24] == 'O' && move[curr - 8] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 8] == 'O')
							if (move[curr - 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					// Case 3
					if (curr < 31) {
						if (move[curr + 24] == 'O' && move[curr + 8] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr + 24] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}
					if (curr > 3 && curr < 38) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 10 && curr < 45) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 17) {
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					// Case 4
					if (curr < 31) {
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 12] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 38 && curr > 3) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 45 && curr > 10) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
					if (curr > 17) {
						if (move[curr - 6] == 'O' && move[curr - 18] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 18] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 4 loop

				  // Simulate diagonal two in a rows for column 5
				if (d == 5) {
					// Case 1
					if (curr > 4 && curr < 39) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr + 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr + 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 11 && curr < 46) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 18) {
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					// Case 2
					if (curr < 32) {
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 12] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 39 && curr > 4) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 46 && curr > 11) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr - 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr - 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 5 loop

				  // Simulate diagonal two in a rows for column 6
				if (d == 6) {
					// Case 1
					if (curr > 12 && curr < 47) {
						if (move[curr - 8] == 'O' && move[curr + 8] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr + 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					if (curr > 19) {
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}

					// Case 2
					if (curr < 33) {
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 12] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;

					if (curr < 40 && curr > 5) {
						if (move[curr - 6] == 'O' && move[curr + 6] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr - 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr - 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 6 loop

				  // Simulate diagonal two in a rows for column 7
				if (d == 7) {
					// Case 1
					if (curr > 20) {
						if (move[curr - 8] == 'O' && move[curr - 16] == 'O')
							if (move[curr - 24] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right two times are 'O' and third is open
									break;
								}
						if (move[curr - 8] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 16] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right and up-right three times are 'O' and second is open
									break;
								}
						if (move[curr - 16] == 'O' && move[curr - 24] == 'O')
							if (move[curr - 8] == ' ')
								if (!clist[d - 1].last) {
									column = d; // Up right is open and up-right two and three times are 'O'
									break;
								}
						if (column != -1)
							break;
					}
					// Case 2
					if (curr < 34) {
						if (move[curr + 6] == 'O' && move[curr + 12] == 'O')
							if (move[curr + 18] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right two times are 'O' and third is open
									break;
								}
						if (move[curr + 6] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 12] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right and down-right three times are 'O' and second is open
									break;
								}
						if (move[curr + 12] == 'O' && move[curr + 18] == 'O')
							if (move[curr + 6] == ' ')
								if (!clist[d - 1].last) {
									column = d; // down right is open and down-right two and three times are 'O'
									break;
								}
					}
					if (column != -1)
						break;
				} // End of diagonal 7 loop

			} // End of entire diagonal for loop
			break;
		} // End of Hard AI decision making LOL

		  // If placing in a column causes a win next turn if ignored and doesn't give user win, go there
	if (column == -1)
		for (int ez = 1; ez < 8; ez++)
			if (!clist[ez - 1].isfull)
				if (!clist[ez - 1].last)
					if (openings[ez - 1] > 6) {
						move[openings[ez - 1]] = 'O';
						if (Check_Win(move, (openings[ez - 1] - 7), 'O', hwin)) {
							column = ez;
							move[openings[ez - 1]] = ' ';
							break;
						}
						move[openings[ez - 1]] = ' ';
					}

	// Standard case for AI turn; pick a random column
	int kounter = 1; // Used to test for while loop
	if (column == -1)
		while (kounter > 0)
		{
			kounter++;
			if (kounter == 100)
				break;
			column = std::rand() % 7 + 1;
			if (clist[column - 1].isfull == true)
				kounter++;
			else if (hard && clist[column - 1].last == true)
				kounter++;
			else
				kounter = 0;
		}

	// Emergency code for case where full row was accidentally selected
	if (clist[column].isfull == true)
		for (gg = 1; gg < 8; gg++)
			if (clist[gg - 1].isfull == false)
			{
				column = gg;
				break;
			}

	// Place AI's chosen move on the board
	k = Get_Bottom(move, column);
	if (k != 49)
		move[k] = 'O';
	if (k <= 6)
		clist[k].isfull = true; // column is now full
	loc = k;
	turn++;
	return column;
}