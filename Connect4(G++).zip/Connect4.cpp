// Connect4.cpp : Defines the entry point for the console application.
// Completed 1-3-2017.
/* This program allows two people on the same computer to play connect 4 on a 7x7 grid.
Alternatively the player can go against a normal or hard computer opponent.*/
#include <iostream>
#include <string>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#ifndef   __CheckWin__h
#define   __CheckWin__h
#include   "CheckWin.h"
#endif
#include "CompMove.h"

using namespace std;
typedef struct _CONSOLE_FONT_INFOEX
{
    ULONG cbSize;
    DWORD nFont;
    COORD dwFontSize;
    UINT  FontFamily;
    UINT  FontWeight;
    WCHAR FaceName[LF_FACESIZE];
}CONSOLE_FONT_INFOEX, *PCONSOLE_FONT_INFOEX;
typedef BOOL (WINAPI*SETCURRENTCONSOLEFONTEX)(HANDLE hConsoleOutput,BOOL bMaximumWindow,CONSOLE_FONT_INFOEX*lpConsoleCurrentFontEx);
SETCURRENTCONSOLEFONTEX SetCurrentConsoleFontEx = (SETCURRENTCONSOLEFONTEX) GetProcAddress(LoadLibraryA("KERNEL32"), "SetCurrentConsoleFontEx");
typedef BOOL (WINAPI*GETCURRENTCONSOLEFONTEX)(HANDLE hConsoleOutput,BOOL bMaximumWindow,CONSOLE_FONT_INFOEX*lpConsoleCurrentFontEx);
GETCURRENTCONSOLEFONTEX GetCurrentConsoleFontEx = (GETCURRENTCONSOLEFONTEX) GetProcAddress(LoadLibraryA("KERNEL32"), "GetCurrentConsoleFontEx");

int Game(bool&, string&, string&);

void ClearScreen()
{
	HANDLE                     hStdOut;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	DWORD                      count;
	DWORD                      cellCount;
	COORD                      homeCoords = { 0, 0 };

	hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hStdOut == INVALID_HANDLE_VALUE) return;

	/* Get the number of cells in the current buffer */
	if (!GetConsoleScreenBufferInfo(hStdOut, &csbi)) return;
	cellCount = csbi.dwSize.X *csbi.dwSize.Y;

	/* Fill the entire buffer with spaces */
	if (!FillConsoleOutputCharacter(
		hStdOut,
		(TCHAR) ' ',
		cellCount,
		homeCoords,
		&count
	)) return;

	/* Fill the entire buffer with the current colors and attributes */
	if (!FillConsoleOutputAttribute(
		hStdOut,
		csbi.wAttributes,
		cellCount,
		homeCoords,
		&count
	)) return;

	/* Move the cursor home */
	SetConsoleCursorPosition(hStdOut, homeCoords);
}

void Color(char c)
// This function displays one character, red for 'X' and black for 'O';
// Additionally, if the character is a winning location, it changes the background to blue
{
	int colour = BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE;
	CONSOLE_SCREEN_BUFFER_INFO info;
	if (c == 'X')
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | colour);
	else if (c == 'x')
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | BACKGROUND_RED);
	else if (c == 'o')
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_BLUE);
	if (c == 'x')
		c = 'X';
	if (c == 'o')
		c = 'O';
	cout << c;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 00 | colour);
}

bool Beginning(bool& first)
/* This function simply asks the user if they would like to hear the rules.
If the user types 'yes' then the rules will be shown before the game starts.
After asking if the user wants to see the rules, the program asks if the user
wants to play alone or with another player.*/
{
	string input;
	if (first) {
		// Set console size
		HWND console = GetConsoleWindow();
		RECT r;
		GetWindowRect(console, &r); //stores the console's current dimensions
		MoveWindow(console, r.left, r.top, 800, 450, TRUE); // 800 width, 450 height

															// Format the colors
		HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
		int colour = BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE;
		SetConsoleTextAttribute(h, 00 | colour);
		ClearScreen();

		// Increase font size a bit
		CONSOLE_FONT_INFOEX cfi;
		cfi.cbSize = sizeof(cfi);
		cfi.nFont = 0;
		cfi.dwFontSize.X = 0;                   // Width of each character in the font
		cfi.dwFontSize.Y = 16;                  // Height
		cfi.FontFamily = FF_DONTCARE;
		cfi.FontWeight = FW_NORMAL;
		SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);

		string yesno;
		double wsize, hsize;
		cout << "Welcome to Connect 4!" << endl << "Type 'rules' if you would like to see the rules," << endl << "or 'skip' to skip." << endl;
		getline(cin, yesno);
		if (yesno[0] == 'r' || yesno[0] == 'R') {
			// Adjust console size here ****************************8
			ClearScreen();
			cout << "1. There are 7 vertical columns and 7 horizontal rows, each numbered between 1 and 7." << endl;
			cout << "2. Each turn, you will pick a column by its number," << endl << "and your move will be put at the bottom of that column." << endl;
			cout << "3. The columns are numbered from left to right, 1 to 7." << endl;
			cout << "4. If there are already pieces in the column, your move will be placed above the highest one." << endl;
			cout << "6. Connect four spaces horizontally, vertically or diagonally before your opponent to win!" << endl;
			cout << "7. Player 1 is shown by the X's, and Player 2 by O's." << endl << "Press any key to continue" << endl;;
			cin.ignore(2);
		}
	}
	// Get number of players
	ClearScreen();
	if (first) {
		cout << "Warning! Adjusting the size of the screen is not recommended and can cause loss of data." << endl << "Press any key to continue" << endl;
		cin.ignore(1);
	}
	while (true)
	{
		ClearScreen();
		input = "";
		cout << "Type one to play against the CPU" << endl << "or two to play with another player." << endl;
		cin >> input;
		if (input[1] == NULL)
			if (input[0] == '1' || input[0] == 'o' || input[0] == 'O')
				return false;
			else if (input == "One" || input == "one")
				return false;
			else if (input == "Two" || input == "two")
				return true;
			else if (input[0] == '2' || input[0] == 't' || input[0] == 'T')
				return true;
	}
}

void Print_Screen(char move[], int turn, int winl[])
/* Each turn, after the player specifies the column for their move, this function will display the board as it currently stands. */
{
	ClearScreen(); //Clear screen for readability
	char ch = ' ';
	string spc = "                               ";
	cout << endl << spc << "     Connect Four to Win!" << endl << endl;
	cout << endl << endl;
	cout << spc << "  1   2   3   4   5   6   7 " << endl;
	cout << spc << " ----------------------------" << endl;
	for (int i = 0; i < 49; i++)
	{
		if (i % 7 == 0)
		{
			cout << spc << "| ";
			for (int c = 0; c < 4; c++)
				if (winl[c] == i) // This is a winning move, show it in color
					if (move[i] == 'X')
						ch = 'x';
					else
						ch = 'o';
			if (ch != 'x' && ch != 'o')
				ch = move[i];
			Color(ch);
			ch = ' ';
		}
		else
		{
			cout << " | ";
			for (int c = 0; c < 4; c++)
				if (winl[c] == i) // This is a winning move, show it in color
					if (move[i] == 'X')
						ch = 'x';
					else
						ch = 'o';
			if (ch != 'x' && ch != 'o')
				ch = move[i];
			Color(ch);
			ch = ' ';
		}
		if (i % 7 == 6) {
			cout << " |" << endl;
			cout << spc << "-----------------------------" << endl;
		}
	}
	cout << endl << endl;
}

void Player_Move(char move[], int& turn, bool& valid, int& loc, CLIST clist[], int AI, int hwin[], string player1, string player2)
/* This function asks for the player to input the column for their move. If they specify a column that does not exist or is already full, the program will provide an error message and ask for valid input until it receives valid input. */
{
	string spc = "                              ";
	string input = ""; // Used to error check user input
	int column;
	if (AI != -1)
		cout << spc << "CPU chose to go in column " << AI << endl;
	if (turn % 2 == 0)
		cout << spc << player1 << ": Pick your column." << endl << spc;
	else
		cout << spc << player2 << ": Pick your column." << endl << spc;
	cin >> input;
	column = input[0] - '0'; // Convert from char to int
	if (input[1] != NULL || column < 1 || column > 7)
	{
		ClearScreen();
		Print_Screen(move, turn, hwin);
		cout << spc << "Your move was invalid. Please pick another column." << endl;
		valid = false;
	}
	else
		for (int i = column + 41; i >= 0;)
		{
			if (move[column - 1] == 'X' || move[column - 1] == 'O')
			{
				cout << "Your move was invalid. Please pick another column." << endl;
				column = 0;
				i = -1;
				valid = false;
			}
			else if (move[i] == ' ')
			{
				if (turn % 2 == 0)
					move[i] = 'X';
				else
					move[i] = 'O';
				if (i <= 6)
					clist[i].isfull = true; // column is now full
				valid = true;
				loc = i;
				i = -1;
				turn++;
			}
			else
				i = i - 7;
		}
}

int main()
{
	string player1 = "Player 1";
	string player2 = "Player 2";
	bool first = true; // Used for first execution of program
	int next = 1;
	while (next)
		next = Game(first, player1, player2);
	return 0;
}

int Game(bool& first, string& player1, string& player2)
// Essentially the main program. Can call itself however
{
	string inp = "";
	bool noname = false;
	int winl[4]; // Location of moves on board which resulted in a win
	int hwin[4]; // Dummy array for check_win function- used for hypotheticals
	bool win = false; // if win == true, a player has connected four in a row
	bool valid = true; // The validity of a move
	bool noplay; // Determines pvp or pvai
	bool hard = false; // Determines hard or normal ai
	char chkwin; // Used to check for win given 'X' or 'O'
	int AI = -1; // Column in which the AI went last turn, always -1 in a pvp game
	int turn = 0; // number of turns into the game
	int loc; // index of array of moves
	char move[50]; // array of moves
	CLIST clist[7]; // Used for AI to determine whether a row is usable
	string next; // Used to query the user if they want another game
	for (int i = 0; i < 49; i++)
		move[i] = ' ';

	// Set-up pre-game information
	for (int ix = 0; ix < 4; ix++)
		winl[ix] = -2;
	for (int ix = 0; ix < 4; ix++)
		hwin[ix] = -1;
	srand(time(NULL));
	// Reformat size of screen here ****************
	noplay = Beginning(first);

	if (!first)
	{
		cout << "Would you like to change any names?" << endl;
		cin >> inp;
	}

	// Ask if player1 wants a nickname
	if (first || inp[0] == 'y' || inp[0] == 'Y') {
		int counter = 0;
		while (true) {
			ClearScreen();
			cout << "Player 1: Enter a username between 1-10 characters if you would like one" << endl;
			cin.ignore();
			getline(cin, inp);
			if (inp.length() > 9)
				counter++;
			else if (inp[0] == 'N' || inp[0] == 'n' || inp.empty()) {
				player1 = "Player 1";
				break;
			}
			else {
				player1 = inp;
				break;
			}
			if (counter == 3) {
				cout << "Default username of Player 1 will be used" << endl << "Press any key to continue" << endl;
				cin.ignore(2);
				break;
			}
		}
		counter = 0;

		// Ask if player2 wants a nickname
		if (noplay)
			while (true) {
				ClearScreen();
				cout << "Player 2: Enter a username between 1-10 characters if you would like one" << endl;
				cin.ignore();
				getline(cin, inp);
				if (inp.length() > 9)
					counter++;
				else if (inp[0] == 'N' || inp[0] == 'n' || inp.empty())
					break;
				else {
					player2 = inp;
					break;
				}
				if (counter == 3) {
					cout << "Default username of Player 2 will be used." << endl << "Press any key to continue" << endl;
					cin.ignore(2);
					break;
				}
			}
	}
	if (first)
		first = false;

	// If player chose to play the AI, get the difficulty level
	if (!noplay) {
		string inp;
		while (true) {
			ClearScreen();
			inp = "";
			cout << "Type 'normal' to play versus normal AI" << endl << "or 'hard' to play versus harder AI" << endl;
			cin >> inp;
			if (inp[0] == 'H' || inp[0] == 'h') {
				hard = true;
				break;
			}
			if (inp[0] == 'n' || inp[0] == 'N')
				break;
		}
	}

	// Loop until game is finished
	while (!win)
	{
		if (turn % 2 == 0)
			chkwin = 'X';
		else
			chkwin = 'O';
		if (valid)
			Print_Screen(move, turn, winl);
		if (turn % 2 == 0 || noplay)
			Player_Move(move, turn, valid, loc, clist, AI, hwin, player1, player2);
		else
			AI = AI_Move(move, turn, loc, clist, hard, hwin);
		if (valid)
			win = Check_Win(move, loc, chkwin, winl);
		if (turn == 49)
			win = true;
	}
	// Display results of game, allow consecutive games
	Print_Screen(move, turn, winl);
	string spc = "                              ";
	if (turn == 49)
		cout << spc << "Tied game!" << endl << spc;
	else if (turn % 2 == 1)
		cout << spc << player1 << " wins!" << endl << spc;
	else if (noplay)
		cout << spc << player2 << " wins!" << endl << spc;
	else
		cout << spc << "CPU wins!" << endl << spc << "Press any key to continue" << endl << spc;
	cin.ignore(2);
	ClearScreen();
	while (true) {
		cout << "Would you like to play again?" << endl;
		cin >> next;
		if (next[0] == 'y' || next[0] == 'Y' || next[0] == 'n' || next[0] == 'Y')
			break;
		ClearScreen();
	}
	if (next[0] == 'y' || next[0] == 'Y')
		return 1;
	else
		return 0;
}